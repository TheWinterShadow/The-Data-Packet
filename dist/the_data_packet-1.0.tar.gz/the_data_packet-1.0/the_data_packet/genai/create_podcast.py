"""
Gemini 2.5 TTS Audio Generator
Converts podcast scripts into audio using Gemini 2.5's native multi-speaker TTS.
"""

import os
import wave
from pathlib import Path
from typing import Optional, Dict, List
from datetime import datetime
import google.generativeai as genai


class GeminiPodcastTTS:
    """
    Generate podcast audio from scripts using Gemini 2.5 TTS.

    Supports:
    - Multi-speaker dialogue (Alex and Sam)
    - Natural pacing and intonation
    - Multiple voice options
    - Automatic chunking for long scripts
    """

    # Available Gemini voices
    AVAILABLE_VOICES = {
        "puck": "Puck - Energetic and dynamic",
        "charon": "Charon - Deep and authoritative",
        "kore": "Kore - Warm and conversational",
        "fenrir": "Fenrir - Rich and engaging",
        "aoede": "Aoede - Clear and professional"
    }

    def __init__(
        self,
        api_key: Optional[str] = None,
        model: str = "gemini-2.5-flash",
        voice_a: str = "Puck",
        voice_b: str = "Kore"
    ):
        """
        Initialize the TTS generator.

        Args:
            api_key: Google API key (defaults to GOOGLE_API_KEY env var)
            model: Gemini model to use ("gemini-2.5-flash" or "gemini-2.5-pro")
            voice_a: Voice for Speaker A (Alex)
            voice_b: Voice for Speaker B (Sam)
        """
        self.api_key = api_key or os.environ.get("GOOGLE_API_KEY")
        if not self.api_key:
            raise ValueError(
                "API key required. Set GOOGLE_API_KEY env var or pass api_key parameter.")

        # Configure Gemini
        genai.configure(api_key=self.api_key)
        self.model_name = model
        self.model = genai.GenerativeModel(model)

        # Voice configuration
        self.voice_a = voice_a
        self.voice_b = voice_b

        print(f"✅ Initialized Gemini TTS")
        print(f"   Model: {model}")
        print(f"   Voice A (Alex): {voice_a}")
        print(f"   Voice B (Sam): {voice_b}")

    def generate_audio(
        self,
        script: str,
        output_file: str = "podcast_episode.wav",
        sample_rate: int = 24000,
        chunk_size: int = 4000
    ) -> str:
        """
        Generate audio from podcast script.

        Args:
            script: TTS-formatted podcast script with speaker labels
            output_file: Output audio file path
            sample_rate: Audio sample rate (default: 24000 Hz)
            chunk_size: Maximum characters per API call (default: 4000)

        Returns:
            Path to generated audio file
        """
        print(f"\n🎙️  Generating podcast audio...")
        print(f"📄 Script length: {len(script)} characters")

        # Check if script needs chunking
        if len(script) > chunk_size:
            print(f"⚠️  Script is long, will process in chunks...")
            return self._generate_chunked_audio(script, output_file, sample_rate, chunk_size)
        else:
            return self._generate_single_audio(script, output_file, sample_rate)

    def _generate_single_audio(
        self,
        script: str,
        output_file: str,
        sample_rate: int
    ) -> str:
        """Generate audio in a single API call."""

        print(f"🔄 Generating audio...")

        # Create TTS prompt
        prompt = self._create_tts_prompt(script)

        try:
            # Generate audio with Gemini
            response = self.model.generate_content(
                prompt,
                generation_config={
                    "response_modalities": ["AUDIO"],
                    "speech_config": {
                        "voice_config": {
                            "prebuilt_voice_config": {
                                "voice_name": self.voice_a
                            }
                        }
                    }
                }
            )

            # Extract audio data
            audio_data = response.candidates[0].content.parts[0].inline_data.data

            # Save to WAV file
            self._save_wav(audio_data, output_file, sample_rate)

            print(f"✅ Audio generated: {output_file}")
            return output_file

        except Exception as e:
            print(f"❌ Error generating audio: {e}")
            raise

    def _generate_chunked_audio(
        self,
        script: str,
        output_file: str,
        sample_rate: int,
        chunk_size: int
    ) -> str:
        """Generate audio in chunks and combine."""

        # Split script into chunks
        chunks = self._split_script(script, chunk_size)
        print(f"📊 Split into {len(chunks)} chunks")

        # Generate audio for each chunk
        chunk_files = []
        for i, chunk in enumerate(chunks, 1):
            print(f"\n🔄 Processing chunk {i}/{len(chunks)}...")

            chunk_file = f"temp_chunk_{i:03d}.wav"

            try:
                # Create prompt for this chunk
                prompt = self._create_tts_prompt(chunk)

                # Generate audio
                response = self.model.generate_content(
                    prompt,
                    generation_config={
                        "response_modalities": ["AUDIO"],
                        "speech_config": {
                            "voice_config": {
                                "prebuilt_voice_config": {
                                    "voice_name": self.voice_a
                                }
                            }
                        }
                    }
                )

                # Extract and save chunk
                audio_data = response.candidates[0].content.parts[0].inline_data.data
                self._save_wav(audio_data, chunk_file, sample_rate)
                chunk_files.append(chunk_file)

                print(f"✅ Chunk {i} complete")

            except Exception as e:
                print(f"❌ Error on chunk {i}: {e}")
                # Clean up any created files
                for cf in chunk_files:
                    if os.path.exists(cf):
                        os.remove(cf)
                raise

        # Combine all chunks
        print(f"\n🔧 Combining {len(chunk_files)} chunks...")
        self._combine_wav_files(chunk_files, output_file, sample_rate)

        # Clean up temporary files
        for chunk_file in chunk_files:
            if os.path.exists(chunk_file):
                os.remove(chunk_file)

        print(f"✅ Audio generated: {output_file}")
        return output_file

    def _create_tts_prompt(self, script: str) -> str:
        """
        Create optimized TTS prompt for Gemini 2.5.

        Args:
            script: Dialogue script with speaker labels

        Returns:
            Formatted prompt for Gemini TTS
        """
        prompt = f"""TTS the following podcast conversation between Alex and Sam:

{script}

Instructions:
- Use natural, conversational pacing
- Alex should sound energetic and engaging
- Sam should sound knowledgeable and clear
- Include natural pauses at sentence breaks
- Maintain distinct voices for each speaker
- Use appropriate intonation for questions and statements"""

        return prompt

    def _split_script(self, script: str, chunk_size: int) -> List[str]:
        """
        Split script into chunks at natural dialogue breaks.

        Args:
            script: Full script text
            chunk_size: Target chunk size in characters

        Returns:
            List of script chunks
        """
        chunks = []
        current_chunk = []
        current_size = 0

        # Split by paragraphs (double newline)
        paragraphs = script.split('\n\n')

        for para in paragraphs:
            para_size = len(para)

            # If adding this paragraph exceeds chunk size, start new chunk
            if current_size + para_size > chunk_size and current_chunk:
                chunks.append('\n\n'.join(current_chunk))
                current_chunk = [para]
                current_size = para_size
            else:
                current_chunk.append(para)
                current_size += para_size

        # Add remaining chunk
        if current_chunk:
            chunks.append('\n\n'.join(current_chunk))

        return chunks

    def _save_wav(
        self,
        audio_data: bytes,
        filename: str,
        sample_rate: int,
        channels: int = 1,
        sample_width: int = 2
    ) -> None:
        """
        Save audio data to WAV file.

        Args:
            audio_data: Raw audio bytes
            filename: Output filename
            sample_rate: Sample rate in Hz
            channels: Number of audio channels
            sample_width: Sample width in bytes
        """
        with wave.open(filename, "wb") as wf:
            wf.setnchannels(channels)
            wf.setsampwidth(sample_width)
            wf.setframerate(sample_rate)
            wf.writeframes(audio_data)

    def _combine_wav_files(
        self,
        input_files: List[str],
        output_file: str,
        sample_rate: int
    ) -> None:
        """
        Combine multiple WAV files into one.

        Args:
            input_files: List of input WAV file paths
            output_file: Output file path
            sample_rate: Sample rate for output
        """
        with wave.open(output_file, 'wb') as output:
            # Set parameters from first file
            with wave.open(input_files[0], 'rb') as first:
                params = first.getparams()
                output.setparams(params)

            # Append all files
            for input_file in input_files:
                with wave.open(input_file, 'rb') as input_wav:
                    output.writeframes(
                        input_wav.readframes(input_wav.getnframes())
                    )

    def generate_from_file(
        self,
        script_file: str,
        output_file: Optional[str] = None
    ) -> str:
        """
        Generate audio from script file.

        Args:
            script_file: Path to TTS script file
            output_file: Optional output file path

        Returns:
            Path to generated audio file
        """
        print(f"📂 Reading script from: {script_file}")

        # Read script
        with open(script_file, 'r', encoding='utf-8') as f:
            script = f.read()

        # Generate output filename if not provided
        if output_file is None:
            script_path = Path(script_file)
            output_file = script_path.stem + ".wav"

        # Generate audio
        return self.generate_audio(script, output_file)

    def estimate_duration(self, script: str) -> float:
        """
        Estimate audio duration in minutes.

        Rough estimate: ~150 words per minute of speech

        Args:
            script: Script text

        Returns:
            Estimated duration in minutes
        """
        # Count words
        words = len(script.split())

        # Estimate duration (150 words per minute)
        duration_minutes = words / 150

        return duration_minutes
