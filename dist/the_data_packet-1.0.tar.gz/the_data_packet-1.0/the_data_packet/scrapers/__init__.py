"""Scraper modules for the_data_packet package."""

from .wired_scraper import WiredArticleScraper

__all__ = ["WiredArticleScraper"]
