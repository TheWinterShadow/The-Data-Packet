"""Version information for the_data_packet."""

__version__ = "1.0"
