"""Data models for the_data_packet package."""

from .article import ArticleData

__all__ = ["ArticleData"]
