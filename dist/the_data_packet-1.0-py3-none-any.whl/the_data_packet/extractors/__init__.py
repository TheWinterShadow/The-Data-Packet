"""Content extraction modules."""

from the_data_packet.extractors.wired_extractor import WiredContentExtractor

__all__ = ["WiredContentExtractor"]
